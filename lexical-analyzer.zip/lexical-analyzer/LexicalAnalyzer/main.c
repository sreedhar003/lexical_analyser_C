#include <stdio.h>
#include<stdlib.h>
#include "lexer.h"

int main(int argc, char *argv[]) {

    const char* tokenTypeNames[] = {"KEYWORD","OPERATOR","SPECIAL_CHARACTER","CONSTANT",
        "IDENTIFIER","UNKNOWN"
    };
    
    if(argc==2 && argv[1][0]!='.')
    {
        system("echo -e \"\033[1;36m$(figlet -f standard LEXICAL ANALYSER)\033[0m\"");
        initializeLexer(argv[1]);

        Token token;
        while (1) {
        token = getNextToken();
        if (token.lexeme[0] == '\0' && token.type == UNKNOWN) {
            break;  // End of file or no more tokens
        }
        printf("Token: %-15s Type: %-10d %s\n", token.lexeme, token.type,tokenTypeNames[token.type]);
        }

        return 0;
    }
    else
    {
        printf("Incorrect Arguments\n");
        return 0;
    }
}
