#include <stdio.h>
#include<stdlib.h>
#include <string.h>
#include <ctype.h>
#include "lexer.h"

static const char* keywords[MAX_KEYWORDS] = {
    "int", "float", "return", "if", "else", "while", "for", "do", "break", "continue",
    "char", "double", "void", "switch", "case", "default", "const", "static", "sizeof", "struct"
};

static const char* operators = "+-*/%=!<>|&";
static const char* specialCharacters = ",;{}()[]";

/* Function Definitions*/
FILE *fp;

void initializeLexer(const char* filename)
{
    Token *tok;
    if(strstr(filename,".c")!=NULL)
    {
        system("echo -e \"\033[1;33m$(figlet -f digital ANALYSER MODE...)\033[0m\"");
        fp=fopen(filename,"r");
        if(fp==NULL)
        {
            printf("Can't open file");
            return;
        }
    }
    else
    {
        printf("Invalid argument of file format\n");
        return;
    }
}
Token getNextToken()
{
    Token token;
    token.lexeme[0] = '\0';
    token.type = UNKNOWN;
    int ch, i = 0;

    if (fp == NULL)
    {
        printf("Lexical not initialized\n");
        exit(0);
    }

    // Skip whitespace
    do {
        ch = fgetc(fp);
    } while (isspace(ch));

    if (ch == EOF)
    {
        token.type = UNKNOWN;
        return token;
    }

    char tempstr[2] = { ch, '\0' };

    // Operator
    if (isOperator(tempstr))
    {
        strcpy(token.lexeme, tempstr);
        token.type = OPERATOR;
        return token;
    }

    // Special character
    if (isSpecialCharacter(ch))
    {
        token.lexeme[0] = ch;
        token.lexeme[1] = '\0';
        token.type = SPECIAL_CHARACTER;
        return token;
    }

    // Identifier or keyword
    if (isalpha(ch) || ch == '_')
    {
        token.lexeme[i++] = ch;
        while ((ch = fgetc(fp)) != EOF && (isalnum(ch) || ch == '_'))
            token.lexeme[i++] = ch;

        token.lexeme[i] = '\0';
        if (ch != EOF) ungetc(ch, fp);

        if (isKeyword(token.lexeme))
            token.type = KEYWORD;
        else
            token.type = IDENTIFIER;
        return token;
    }

    // Number
    if (isdigit(ch))
    {
        token.lexeme[i++] = ch;
        int dot_count = 0;
        while ((ch = fgetc(fp)) != EOF && (isdigit(ch) || (ch == '.' && !dot_count)))
        {
            if (ch == '.') dot_count = 1;
            token.lexeme[i++] = ch;
        }
        token.lexeme[i] = '\0';
        if (ch != EOF) ungetc(ch, fp);

        token.type = CONSTANT;
        return token;
    }

    // Unknown token
    token.lexeme[0] = ch;
    token.lexeme[1] = '\0';
    token.type = UNKNOWN;
    return token;
}



int isKeyword(const char* str){
    for(int i=0;i<MAX_KEYWORDS;i++)
    {
        if(strcmp(str,keywords[i])==0)
        {
            return 1;
        }
    }
    return 0;
}
int isOperator(const char* str){
    if(strstr(str,operators)!=NULL)
    {
        return 1;
    }
    return 0;
}
int isSpecialCharacter(char ch){
    if(strchr(specialCharacters,ch)!=NULL)
    {
        return 1;
    }
    return 0;
}
